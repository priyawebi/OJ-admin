import React from "react";
import { SortableHandle } from "react-sortable-hoc";
const RowHandler = SortableHandle(() => <div className="handle">move</div>);
const TableRow = ({ first, second, third, fourth }: any) => {
    return (
        <tr className={"move_table_tr"}>
            <td>{first}</td>
            <td>{second}</td>
            <td>{third}</td>
            <td><RowHandler /></td>
        </tr>
    );
};

export default TableRow;
