import React, { useEffect, useState } from 'react';
import { Col, Form, Row } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Collapse from 'react-bootstrap/Collapse';
import Router from "next/router";

import Sidebar from 'components/_common/Sidebar'
import Header from 'components/_common/Header'
import CustomTable from 'components/_common/CustomTable'

function editableValuesList() {
    const [loadingText, setLoadingText] = useState('');
    const [open, setOpen] = useState(false);
    const [page, setPage] = useState(1);
    const [totalPage, setTotalPage] = useState(5);
    const [tableData, setTableData] = useState([])
    const [keyValue, setKeyValue] = useState({
        name: "NAME",
        category: "CATEGORY",
        value: "VALUE"
    })


    const clickAction = (data: any) => {
        Router.push("/gem-shape-list?id=" + data.id);
    }

    useEffect(() => {
        setLoadingText('Loading...');
        getCustomerData(10, page)
    }, [page]);

    const getCustomerData = (limit: number, page: number) => {
        fetch(`http://localhost:3000/editableValues?_limit=${100}&_page=${page}`)
            .then((res) =>
                res.json())
            .then((response) => {
                if (response && response.length) {
                    response.forEach((e: { status: String; subscription: String; }, i: number) => {
                        response[i].clickAction = clickAction;
                    })
                    setTableData(response);
                    const totalRecord = 1;
                    setTotalPage(Math.ceil(totalRecord / limit));
                    setLoadingText('')
                } else {
                    setLoadingText('No Result Fount')
                }
            })
    }

    return (
        <>
            <div className="App">
                <div>
                    <Header />
                </div>
                <div>
                    <Sidebar activeBar={"editableValue"} />
                </div>
            </div>
            <div className='main-content'>
                <div className='m-4'>
                    <Row className='mb-3'>
                        <Col xs={6}>
                            <div>
                                <h3 className='table-head-text'>Editable Values</h3>
                            </div>
                        </Col>
                    </Row>

                    <div className='mt-3 card shadow'> {loadingText ? <p style={{ textAlign: "center", marginTop: "15px" }}>{loadingText}</p> :
                        <CustomTable page={page} totalPage={totalPage} setPage={setPage} keyValue={keyValue} tableData={tableData} />}
                    </div>
                </div>
            </div>undefined
        </>
    )
}

export default editableValuesList;