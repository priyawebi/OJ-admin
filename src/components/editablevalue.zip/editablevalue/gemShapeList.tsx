import React, { useState, useCallback } from "react";
import TableRow from "./TableRow";
import { SortableContainer, SortableElement } from "react-sortable-hoc";
import arrayMove from "./arrayMove";

const SortableCont:any = SortableContainer(({ children }: any) => {
    return <tbody>{children}</tbody>;
});

const SortableItem = SortableElement((props: any) => <TableRow {...props} />);

const MyTable = () => {
    const [items, setItems] = useState(
        [
            {
                first: "She",
                second: "was",
                third: "a",
                fourth: "fast"
            },
            {
                first: "machine",
                second: "She",
                third: "kept",
                fourth: "her"
            },
            {
                first: "motor",
                second: "clean",
                third: "She",
                fourth: "was"
            },
            {
                first: "the",
                second: "best",
                third: "damn",
                fourth: "woman"
            },
            {
                first: "I",
                second: "had",
                third: "ever",
                fourth: "seen"
            },
            {
                first: "She",
                second: "had",
                third: "the",
                fourth: "sightless"
            },
            {
                first: "eyes",
                second: "telling",
                third: "me",
                fourth: "no"
            },
            {
                first: "lies",
                second: "knockin'",
                third: "me",
                fourth: "out"
            },
            {
                first: "with",
                second: "those",
                third: "American",
                fourth: "thighs"
            },
            {
                first: "taking",
                second: "more",
                third: "than",
                fourth: "her"
            },
            {
                first: "share",
                second: "had",
                third: "me",
                fourth: "fighting"
            },
            {
                first: "for",
                second: "air",
                third: "She",
                fourth: "told"
            },
            {
                first: "me",
                second: "to",
                third: "come",
                fourth: "but"
            },
            {
                first: "I",
                second: "was",
                third: "already",
                fourth: "there"
            },
            {
                first: "'cause",
                second: "the",
                third: "walls",
                fourth: "start"
            },
            {
                first: "shaking",
                second: "the",
                third: "earth",
                fourth: "was"
            },
            {
                first: "quaking",
                second: "my",
                third: "mind",
                fourth: "was"
            },
            {
                first: "aching",
                second: "and",
                third: "we",
                fourth: "were"
            },
            {
                first: "making",
                second: "it",
                third: "and",
                fourth: "you"
            }
        ]
    );

    const onSortEnd = useCallback(({ oldIndex, newIndex }: any) => {
        setItems(oldItems => arrayMove(oldItems, oldIndex, newIndex));
    }, []);

    return (
        <div className="fixed_header_div">
            <table className="table table-light fixed_header">
                <thead>
                    <tr>
                        <th>First</th>
                        <th>Second</th>
                        <th>Third</th>
                        <th>Forth</th>
                    </tr>
                </thead>
                <SortableCont
                    onSortEnd={onSortEnd}
                    axis="y"
                    lockAxis="y"
                    lockToContainerEdges={true}
                    lockOffset={["50%", "50%"]}
                    helperClass="helperContainerClass"
                    useDragHandle={true}
                >
                    {items.map((value, index) => (
                        <SortableItem
                            key={`item-${index}`}
                            index={index}
                            first={value.first}
                            second={value.second}
                            third={value.third}
                            fourth={value.fourth}
                        />
                    ))}
                </SortableCont>
            </table>
        </div>
    );
};

export default MyTable;























// import Table from 'react-bootstrap/Table'
// import { List, arrayMove } from 'react-movable';
// import * as React from 'react';

// import Sidebar from 'components/_common/Sidebar'
// import Header from 'components/_common/Header'

// function GemShapeList() {

//     const [items, setItems] = React.useState(['Item 1', 'Item 2', 'Item 3']);

//     return (
//         <>
//             <div className="App">
//                 <div>
//                     <Header />
//                 </div>
//                 <div>
//                     <Sidebar activeBar={"editableValue"} />
//                 </div>
//             </div>
//             <div className='main-content'>
//                 <div className='m-4'>
//                     <List
//                         values={items}
//                         onChange={({ oldIndex, newIndex }) =>
//                             setItems(arrayMove(items, oldIndex, newIndex))
//                         }
//                         renderList={({ children, props }) => {

//                             return (
//                                 <table {...props} style={{ border: "1px solid red", width: "100%" }}>
//                                     <tr>
//                                         <th>Company</th>
//                                         <th>Contact</th>
//                                         <th>Country</th>
//                                     </tr>
//                                     {children}
//                                 </table>
//                             )

//                             //return (<div {...props}>{children}</div>)
//                         }}
//                         //renderItem={({ value, props }) => {
//                         renderItem={({ value, props }) => {
//                             return (
//                                 <tr {...props} style={{ border: "1px solid green" }} >
//                                     <td >{value}</td>
//                                     <td>Maria Anders</td>
//                                     <td >Germany</td>
//                                 </tr>

//                             )
//                             return (<p {...props}>{value}</p>)
//                         }}
//                     />
//                 </div>
//             </div>
//         </>
//     )
// }

// export default GemShapeList